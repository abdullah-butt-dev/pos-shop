import { jsPDF } from "jspdf"

export interface OrderItem {
  id: string
  name: string
  price: number
  quantity: number
}

export interface Order {
  tableNumber: string
  items: OrderItem[]
  subtotal: number
  tax: number
  total: number
  timestamp: Date
}

export function generateBillPDF(order: Order): void {
  const doc = new jsPDF()
  const pageWidth = doc.internal.pageSize.getWidth()
  const pageHeight = doc.internal.pageSize.getHeight()
  let yPosition = 20

  // Header
  doc.setFontSize(20)
  doc.text("SSG Store", pageWidth / 2, yPosition, { align: "center" })
  yPosition += 10

  doc.setFontSize(10)
  doc.text("Bill Receipt", pageWidth / 2, yPosition, { align: "center" })
  yPosition += 8

  // Table info
  doc.setFontSize(11)
  doc.text(`Table: ${order.tableNumber}`, 20, yPosition)
  yPosition += 6
  doc.text(`Date: ${order.timestamp.toLocaleDateString()}`, 20, yPosition)
  doc.text(`Time: ${order.timestamp.toLocaleTimeString()}`, 120, yPosition)
  yPosition += 12

  // Items table header
  doc.setFontSize(10)
  doc.setFont(undefined, "bold")
  doc.text("Item", 20, yPosition)
  doc.text("Qty", 120, yPosition)
  doc.text("Price", 150, yPosition)
  doc.text("Total", 180, yPosition)
  yPosition += 8

  // Items
  doc.setFont(undefined, "normal")
  order.items.forEach((item) => {
    const itemTotal = item.price * item.quantity
    doc.text(item.name, 20, yPosition)
    doc.text(item.quantity.toString(), 120, yPosition)
    doc.text(`₹${item.price}`, 150, yPosition)
    doc.text(`₹${itemTotal}`, 180, yPosition)
    yPosition += 6
  })

  yPosition += 4

  // Totals
  doc.setFont(undefined, "bold")
  doc.text(`Subtotal: ₹${order.subtotal.toFixed(2)}`, 150, yPosition)
  yPosition += 6
  doc.text(`Tax (10%): ₹${order.tax.toFixed(2)}`, 150, yPosition)
  yPosition += 8

  doc.setFontSize(12)
  doc.text(`Total: ₹${order.total.toFixed(2)}`, 150, yPosition)

  // Footer
  yPosition = pageHeight - 20
  doc.setFontSize(8)
  doc.text("Thank you for your order!", pageWidth / 2, yPosition, { align: "center" })

  // Save PDF
  doc.save(`bill-${order.tableNumber}-${Date.now()}.pdf`)
}
