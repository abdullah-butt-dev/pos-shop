"use client"

import { IndianRupee, QrCode, Wallet, Download, ShoppingBag } from "lucide-react"
import { useState } from "react"
import { useCart } from "./cart-context"
import { generateBillPDF } from "@/lib/pdf-generator"
import { useStore } from "@/lib/store"

export function OrderSummary({ priceMode }: { priceMode: "retail" | "wholesale" }) {
  const { items, subtotal, clear } = useCart()
  const { addOrder, incrementProductOrder, decrementStock } = useStore()
  const [tableNumber, setTableNumber] = useState("Table 5")
  const [isGenerating, setIsGenerating] = useState(false)

  const tax = subtotal * 0.1
  const total = subtotal + tax

  const handlePlaceOrder = async () => {
    if (items.length === 0) {
      alert("Please add items to the order")
      return
    }

    setIsGenerating(true)
    try {
      const order = {
        id: `order-${Date.now()}`,
        items: items.map((item) => ({
          productId: item.id,
          quantity: item.qty,
          price: item.price,
        })),
        total,
        date: new Date().toISOString(),
        tableNumber,
        type: priceMode,
      }
      addOrder(order)

      items.forEach((item) => {
        incrementProductOrder(item.id)
        decrementStock(item.id, item.qty)
      })

      // Generate PDF
      generateBillPDF({
        tableNumber,
        items: items.map((item) => ({
          id: item.id,
          name: item.name,
          price: item.price,
          quantity: item.qty,
        })),
        subtotal,
        tax,
        total,
        timestamp: new Date(),
      })

      clear()

      alert("Order placed successfully! Bill downloaded.")
    } catch (error) {
      console.error("Error generating bill:", error)
      alert("Error generating bill. Please try again.")
    } finally {
      setIsGenerating(false)
    }
  }

  return (
    <aside className="pos-panel w-96 shrink-0 p-4 flex flex-col gap-4">
      <header className="flex items-center justify-between">
        <div>
          <div className="text-sm font-semibold">Main Branch</div>
          <div className="text-xs text-foreground/60">{tableNumber}</div>
        </div>
        <button className="pos-panel rounded-full p-2" aria-label="Edit table" />
      </header>

      {items.length === 0 ? (
        <div className="flex-1 flex flex-col items-center justify-center gap-4 text-center py-12">
          <div className="p-4 rounded-full bg-muted/50">
            <ShoppingBag className="w-12 h-12 text-muted-foreground" />
          </div>
          <div>
            <p className="text-lg font-medium text-muted-foreground">Cart is empty</p>
            <p className="text-sm text-muted-foreground/60 mt-1">Add items to place an order</p>
          </div>
        </div>
      ) : (
        <>
          <div className="grid gap-2">
            {items.map((i, idx) => (
              <div key={i.id} className="pos-panel flex items-center justify-between rounded-lg px-3 py-2">
                <div className="flex items-center gap-2">
                  <span className="pos-panel h-6 w-6 rounded-full grid place-items-center text-xs">{idx + 1}</span>
                  <div className="text-sm">
                    {i.name} x{i.qty}
                  </div>
                </div>
                <div className="font-semibold">₹{(i.price * i.qty).toFixed(2)}</div>
              </div>
            ))}
          </div>

          <div className="pos-panel rounded-xl p-4 grid gap-2">
            <div className="flex items-center justify-between text-sm">
              <span>Subtotal</span>
              <span>₹{subtotal.toFixed(2)}</span>
            </div>
            <div className="flex items-center justify-between text-sm">
              <span>Tax 10%</span>
              <span>₹{tax.toFixed(2)}</span>
            </div>
            <hr className="my-1 border-[var(--pos-stroke)]" />
            <div className="flex items-center justify-between text-base">
              <span className="font-medium">Total</span>
              <span className="font-bold">₹{total.toFixed(2)}</span>
            </div>
          </div>

          <div>
            <div className="text-sm mb-2">Payment Method</div>
            <div className="grid grid-cols-3 gap-2">
              <button className="pos-panel rounded-lg py-3 text-sm grid place-items-center">
                <IndianRupee className="h-5 w-5" aria-hidden />
                <span className="sr-only">Cash</span>
              </button>
              <button className="pos-panel rounded-lg py-3 text-sm grid place-items-center">
                <Wallet className="h-5 w-5" aria-hidden />
                <span className="sr-only">Debit Card</span>
              </button>
              <button className="pos-panel rounded-lg py-3 text-sm grid place-items-center">
                <QrCode className="h-5 w-5" aria-hidden />
                <span className="sr-only">E-Wallet</span>
              </button>
            </div>
          </div>

          <button
            onClick={handlePlaceOrder}
            disabled={isGenerating}
            className="mt-auto rounded-full py-3 text-center font-medium bg-foreground text-background hover:opacity-90 disabled:opacity-50 transition flex items-center justify-center gap-2"
          >
            <Download size={18} />
            {isGenerating ? "Generating..." : "Place Order"}
          </button>
        </>
      )}
    </aside>
  )
}
