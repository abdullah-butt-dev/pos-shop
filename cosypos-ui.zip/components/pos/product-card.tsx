"use client"

import { useCart } from "./cart-context"
import { Minus, Plus } from "lucide-react"
import { cn } from "@/lib/utils"

export function ProductCard({
  id,
  name,
  price,
  highlight,
}: {
  id: string
  name: string
  price: number
  highlight?: "tile-pink" | "tile-blue" | "tile-purple"
}) {
  const { items, inc, dec, add } = useCart()
  const item = items.find((i) => i.id === id)
  const qty = item?.qty ?? 0

  return (
    <div className={cn("tile p-4 bg-[var(--pos-panel)] text-foreground", highlight)}>
      <div className="text-xs text-foreground/60 mb-2">{"Orders > Kitchen"}</div>
      <div className="font-medium">{name}</div>
      <div className="text-sm text-foreground/70">₹{price.toFixed(2)}</div>

      <div className="mt-6 flex items-center gap-2">
        <button
          className="pos-panel rounded-md px-2 py-1 text-sm disabled:opacity-50"
          aria-label={`Decrease ${name}`}
          onClick={() => {
            if (qty > 0) dec(id)
          }}
          disabled={qty === 0}
        >
          <Minus className="h-4 w-4" />
        </button>
        <div className="pos-panel rounded-md px-3 py-1 text-sm min-w-8 text-center">{qty}</div>
        <button
          className="pos-panel rounded-md px-2 py-1 text-sm"
          aria-label={`Increase ${name}`}
          onClick={() => {
            if (qty > 0) {
              inc(id)
            } else {
              add({ id, name, price })
            }
          }}
        >
          <Plus className="h-4 w-4" />
        </button>
      </div>
    </div>
  )
}
