"use client"

import { useState, useMemo, useEffect } from "react"
import { Sidebar } from "@/components/pos/sidebar"
import { useStore } from "@/lib/store"
import { TrendingUp, IndianRupee, Package, AlertTriangle, ShoppingCart, Calendar, Clock } from "lucide-react"

export default function DashboardPage() {
  const { products, orders, updateProduct } = useStore()
  const [priceMode, setPriceMode] = useState<"retail" | "wholesale">("retail")
  const [currentTime, setCurrentTime] = useState(new Date())

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 60000)
    return () => clearInterval(timer)
  }, [])

  const analytics = useMemo(() => {
    const totalSales = orders.reduce((sum, order) => sum + order.total, 0)
    const totalProfit = totalSales * 0.3
    const mostOrdered = [...products].sort((a, b) => b.orderCount - a.orderCount).slice(0, 5)
    const lowStock = products.filter((p) => p.stock <= p.lowStockThreshold)
    return { totalSales, totalProfit, mostOrdered, lowStock }
  }, [products, orders])

  const handleOrderMore = (productId: string) => {
    const product = products.find((p) => p.id === productId)
    if (product) {
      updateProduct(productId, { stock: product.stock + 50 })
    }
  }

  return (
    <main className="h-full w-full flex flex-col overflow-hidden">
      <div className="flex-1 flex flex-col p-3 gap-3 overflow-hidden">
        <div className="pos-panel flex-1 flex overflow-hidden">
          <div className="flex gap-3 flex-1 overflow-hidden">
            <Sidebar />
            <section className="flex-1 flex flex-col gap-4 overflow-y-auto p-4">
              <div className="flex items-center justify-between">
                <div>
                  <h1 className="text-2xl font-bold">Dashboard</h1>
                  <div className="flex items-center gap-3 text-sm text-muted-foreground mt-1">
                    <div className="flex items-center gap-1">
                      <Calendar className="w-3.5 h-3.5" />
                      <span>
                        {currentTime.toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" })}
                      </span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5" />
                      <span>{currentTime.toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit" })}</span>
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2 pos-panel p-1">
                  <button
                    onClick={() => setPriceMode("retail")}
                    className={`px-4 py-2 rounded-lg text-sm font-medium transition ${
                      priceMode === "retail" ? "bg-pos-brand text-foreground" : "text-muted-foreground"
                    }`}
                  >
                    Retail
                  </button>
                  <button
                    onClick={() => setPriceMode("wholesale")}
                    className={`px-4 py-2 rounded-lg text-sm font-medium transition ${
                      priceMode === "wholesale" ? "bg-pos-brand text-foreground" : "text-muted-foreground"
                    }`}
                  >
                    Wholesale
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="pos-panel p-6">
                  <div className="flex items-center gap-3">
                    <div className="p-3 rounded-lg bg-pos-brand/20">
                      <IndianRupee className="w-6 h-6 text-pos-brand" />
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Total Sales</p>
                      <p className="text-2xl font-bold">₹{analytics.totalSales.toFixed(2)}</p>
                    </div>
                  </div>
                </div>

                <div className="pos-panel p-6">
                  <div className="flex items-center gap-3">
                    <div className="p-3 rounded-lg bg-pos-accent-pink/20">
                      <TrendingUp className="w-6 h-6" style={{ color: "var(--pos-accent-pink)" }} />
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Total Profit</p>
                      <p className="text-2xl font-bold">₹{analytics.totalProfit.toFixed(2)}</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Most Ordered Products */}
              <div className="pos-panel p-6">
                <div className="flex items-center gap-2 mb-4">
                  <Package className="w-5 h-5 text-pos-brand" />
                  <h2 className="text-lg font-semibold">Most Ordered Products</h2>
                </div>
                <div className="space-y-3">
                  {analytics.mostOrdered.map((product, index) => (
                    <div key={product.id} className="flex items-center justify-between p-3 rounded-lg bg-background/50">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-pos-brand/20 flex items-center justify-center text-sm font-bold">
                          {index + 1}
                        </div>
                        <div>
                          <p className="font-medium">{product.name}</p>
                          <p className="text-sm text-muted-foreground">
                            ₹{priceMode === "retail" ? product.retailPrice : product.wholesalePrice} • Stock:{" "}
                            {product.stock}
                          </p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-semibold">{product.orderCount} orders</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Low Stock Items */}
              <div className="pos-panel p-6">
                <div className="flex items-center gap-2 mb-4">
                  <AlertTriangle className="w-5 h-5 text-destructive" />
                  <h2 className="text-lg font-semibold">Low Stock Items</h2>
                  <span className="px-2 py-1 rounded-full bg-destructive/20 text-destructive text-xs font-medium">
                    {analytics.lowStock.length}
                  </span>
                </div>
                <div className="space-y-3">
                  {analytics.lowStock.length === 0 ? (
                    <p className="text-muted-foreground text-center py-8">All items are well stocked!</p>
                  ) : (
                    analytics.lowStock.map((product) => (
                      <div
                        key={product.id}
                        className="flex items-center justify-between p-3 rounded-lg bg-destructive/5 border border-destructive/20"
                      >
                        <div>
                          <p className="font-medium">{product.name}</p>
                          <p className="text-sm text-muted-foreground">
                            Current Stock: <span className="text-destructive font-semibold">{product.stock}</span> •
                            Threshold: {product.lowStockThreshold}
                          </p>
                        </div>
                        <button
                          onClick={() => handleOrderMore(product.id)}
                          className="flex items-center gap-2 px-4 py-2 bg-pos-brand text-foreground rounded-lg hover:opacity-90 transition"
                        >
                          <ShoppingCart className="w-4 h-4" />
                          Order More
                        </button>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </section>
          </div>
        </div>
      </div>
    </main>
  )
}
