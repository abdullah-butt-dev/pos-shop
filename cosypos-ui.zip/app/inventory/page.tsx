"use client"

import type React from "react"

import { useState, useMemo } from "react"
import { Sidebar } from "@/components/pos/sidebar"
import { useStore, type Product } from "@/lib/store"
import { Plus, Pencil, Trash2 } from "lucide-react"

export default function InventoryPage() {
  const { categories, products, addProduct, updateProduct, deleteProduct, addCategory } = useStore()
  const [selectedCategory, setSelectedCategory] = useState(categories[0]?.id || "")
  const [showForm, setShowForm] = useState(false)
  const [editingProduct, setEditingProduct] = useState<Product | null>(null)
  const [newCategoryName, setNewCategoryName] = useState("")

  const filteredProducts = useMemo(
    () => products.filter((p) => p.category === selectedCategory),
    [products, selectedCategory],
  )

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    const formData = new FormData(e.currentTarget)
    const productData = {
      id: editingProduct?.id || `product-${Date.now()}`,
      name: formData.get("name") as string,
      retailPrice: Number(formData.get("retailPrice")),
      wholesalePrice: Number(formData.get("wholesalePrice")),
      price: Number(formData.get("retailPrice")),
      category: selectedCategory,
      stock: Number(formData.get("stock")),
      lowStockThreshold: Number(formData.get("lowStockThreshold")),
      orderCount: editingProduct?.orderCount || 0,
    }

    if (editingProduct) {
      updateProduct(editingProduct.id, productData)
    } else {
      addProduct(productData)
    }

    setShowForm(false)
    setEditingProduct(null)
  }

  const handleAddCategory = () => {
    if (newCategoryName.trim()) {
      addCategory({
        id: newCategoryName.toLowerCase().replace(/\s+/g, "-"),
        name: newCategoryName,
        color: "tile-pink",
      })
      setNewCategoryName("")
    }
  }

  return (
    <main className="h-full w-full flex flex-col overflow-hidden">
      <div className="flex-1 flex flex-col p-3 gap-3 overflow-hidden">
        <div className="pos-panel flex-1 flex overflow-hidden">
          <div className="flex gap-3 flex-1 overflow-hidden">
            <Sidebar />
            <section className="flex-1 flex flex-col gap-4 overflow-hidden p-4">
              <div className="flex items-center justify-between">
                <h1 className="text-2xl font-bold">Inventory Management</h1>
                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder="New category name"
                    value={newCategoryName}
                    onChange={(e) => setNewCategoryName(e.target.value)}
                    className="px-3 py-2 rounded-lg bg-background border border-border text-sm"
                  />
                  <button
                    onClick={handleAddCategory}
                    className="px-4 py-2 bg-pos-brand text-foreground rounded-lg hover:opacity-90 transition"
                  >
                    Add Category
                  </button>
                </div>
              </div>

              <div className="flex gap-4 flex-1 overflow-hidden">
                {/* Categories sidebar */}
                <div className="w-64 pos-panel p-4 overflow-y-auto">
                  <h3 className="font-semibold mb-3">Categories</h3>
                  <div className="space-y-2">
                    {categories.map((cat) => (
                      <button
                        key={cat.id}
                        onClick={() => setSelectedCategory(cat.id)}
                        className={`w-full text-left px-3 py-2 rounded-lg transition ${
                          selectedCategory === cat.id
                            ? "bg-pos-brand text-foreground"
                            : "hover:bg-background/50 text-muted-foreground"
                        }`}
                      >
                        {cat.name}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Products list */}
                <div className="flex-1 flex flex-col gap-4 overflow-hidden">
                  <div className="flex items-center justify-between">
                    <h2 className="text-xl font-semibold">
                      {categories.find((c) => c.id === selectedCategory)?.name} Products
                    </h2>
                    <button
                      onClick={() => {
                        setEditingProduct(null)
                        setShowForm(true)
                      }}
                      className="flex items-center gap-2 px-4 py-2 bg-pos-brand text-foreground rounded-lg hover:opacity-90 transition"
                    >
                      <Plus className="w-4 h-4" />
                      Add Product
                    </button>
                  </div>

                  {showForm && (
                    <form onSubmit={handleSubmit} className="pos-panel p-4 space-y-3">
                      <input
                        name="name"
                        placeholder="Product Name"
                        defaultValue={editingProduct?.name}
                        required
                        className="w-full px-3 py-2 rounded-lg bg-background border border-border"
                      />
                      <div className="grid grid-cols-2 gap-3">
                        <input
                          name="retailPrice"
                          type="number"
                          placeholder="Retail Price"
                          defaultValue={editingProduct?.retailPrice}
                          required
                          className="px-3 py-2 rounded-lg bg-background border border-border"
                        />
                        <input
                          name="wholesalePrice"
                          type="number"
                          placeholder="Wholesale Price"
                          defaultValue={editingProduct?.wholesalePrice}
                          required
                          className="px-3 py-2 rounded-lg bg-background border border-border"
                        />
                        <input
                          name="stock"
                          type="number"
                          placeholder="Stock Quantity"
                          defaultValue={editingProduct?.stock}
                          required
                          className="px-3 py-2 rounded-lg bg-background border border-border"
                        />
                        <input
                          name="lowStockThreshold"
                          type="number"
                          placeholder="Low Stock Threshold"
                          defaultValue={editingProduct?.lowStockThreshold}
                          required
                          className="px-3 py-2 rounded-lg bg-background border border-border"
                        />
                      </div>
                      <div className="flex gap-2">
                        <button
                          type="submit"
                          className="px-4 py-2 bg-pos-brand text-foreground rounded-lg hover:opacity-90 transition"
                        >
                          {editingProduct ? "Update" : "Add"} Product
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            setShowForm(false)
                            setEditingProduct(null)
                          }}
                          className="px-4 py-2 bg-background border border-border rounded-lg hover:bg-background/50 transition"
                        >
                          Cancel
                        </button>
                      </div>
                    </form>
                  )}

                  <div className="flex-1 overflow-y-auto space-y-2">
                    {filteredProducts.map((product) => (
                      <div key={product.id} className="pos-panel p-4 flex items-center justify-between">
                        <div>
                          <p className="font-medium">{product.name}</p>
                          <p className="text-sm text-muted-foreground">
                            Retail: Rs {product.retailPrice} • Wholesale: Rs {product.wholesalePrice} • Stock:{" "}
                            {product.stock}
                          </p>
                        </div>
                        <div className="flex gap-2">
                          <button
                            onClick={() => {
                              setEditingProduct(product)
                              setShowForm(true)
                            }}
                            className="p-2 hover:bg-background/50 rounded-lg transition"
                          >
                            <Pencil className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => deleteProduct(product.id)}
                            className="p-2 hover:bg-destructive/20 text-destructive rounded-lg transition"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </section>
          </div>
        </div>
      </div>
    </main>
  )
}
