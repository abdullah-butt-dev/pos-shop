"use client"

import { useState, useMemo } from "react"
import { Sidebar } from "@/components/pos/sidebar"
import { SearchBar } from "@/components/pos/search-bar"
import { CategoryCard } from "@/components/pos/category-card"
import { ProductCard } from "@/components/pos/product-card"
import { OrderSummary } from "@/components/pos/order-summary"
import { CartProvider } from "@/components/pos/cart-context"
import { useStore } from "@/lib/store"
import { Sparkles } from "lucide-react"

export default function OrdersPage() {
  const { categories, products } = useStore()
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null)
  const [searchQuery, setSearchQuery] = useState("")
  const [priceMode, setPriceMode] = useState<"retail" | "wholesale">("retail")

  const filteredProducts = useMemo(() => {
    let filtered = products

    if (selectedCategory) {
      filtered = filtered.filter((p) => p.category === selectedCategory)
    }

    if (searchQuery) {
      filtered = filtered.filter((p) => p.name.toLowerCase().includes(searchQuery.toLowerCase()))
    }

    return filtered
  }, [products, selectedCategory, searchQuery])

  const mostOrderedProducts = useMemo(() => {
    return [...products].sort((a, b) => b.orderCount - a.orderCount).slice(0, 4)
  }, [products])

  const handleCategoryClick = (categoryId: string) => {
    setSelectedCategory(selectedCategory === categoryId ? null : categoryId)
  }

  return (
    <CartProvider>
      <main className="h-full w-full flex flex-col overflow-hidden">
        <div className="flex-1 flex flex-col p-3 gap-3 overflow-hidden">
          <div className="pos-panel flex-1 flex overflow-hidden">
            <div className="flex gap-3 flex-1 overflow-hidden">
              <Sidebar />
              <section className="flex-1 flex flex-col gap-3 overflow-hidden">
                <div className="flex items-center justify-between">
                  <SearchBar onSearch={setSearchQuery} />
                  <div className="flex items-center gap-2 pos-panel p-1">
                    <button
                      onClick={() => setPriceMode("retail")}
                      className={`px-4 py-2 rounded-lg text-sm font-medium transition ${
                        priceMode === "retail" ? "bg-pos-brand text-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Retail
                    </button>
                    <button
                      onClick={() => setPriceMode("wholesale")}
                      className={`px-4 py-2 rounded-lg text-sm font-medium transition ${
                        priceMode === "wholesale" ? "bg-pos-brand text-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Wholesale
                    </button>
                  </div>
                </div>

                <div className="flex flex-col gap-2">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Sparkles className="w-4 h-4" />
                    <span>Most Ordered</span>
                  </div>
                  <div className="grid grid-cols-4 gap-2">
                    {mostOrderedProducts.map((p) => (
                      <div
                        key={p.id}
                        className="tile tile-mint p-2 text-xs flex items-center justify-between cursor-pointer hover:opacity-80"
                      >
                        <span className="font-medium truncate">{p.name}</span>
                        <span className="text-[10px] opacity-70">{p.orderCount} orders</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Categories */}
                <div className="grid grid-cols-4 gap-2">
                  {categories.map((c) => (
                    <CategoryCard
                      key={c.id}
                      title={c.name}
                      items={products.filter((p) => p.category === c.id).length}
                      color={c.color}
                      onClick={() => handleCategoryClick(c.id)}
                      isSelected={selectedCategory === c.id}
                    />
                  ))}
                </div>

                <div className="flex-1 overflow-y-auto">
                  <div className="grid grid-cols-4 gap-2 pb-2">
                    {filteredProducts.map((p) => (
                      <ProductCard
                        key={p.id}
                        id={p.id}
                        name={p.name}
                        price={priceMode === "retail" ? p.retailPrice : p.wholesalePrice}
                      />
                    ))}
                  </div>
                </div>
              </section>

              <OrderSummary priceMode={priceMode} />
            </div>
          </div>
        </div>
      </main>
    </CartProvider>
  )
}
